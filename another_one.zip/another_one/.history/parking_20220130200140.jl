{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           16,650 \u20ac ", "consumption": "e220 bluetec amg line 5-door", "date": " 17/02/2020", "fuel_type": "Diesel", "mileage": "115,873 Km", "year": "2014", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           19,275 \u20ac ", "consumption": "sportivo 120ps", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2022", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Doblo", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           19,037 \u20ac ", "consumption": "1.6 105hp tecnico metallic grey (photos are for illustration purposes only inquire for mor", "date": " 29/02/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "-", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "3 series convertible", "engine_size": "M3", "model_type": "M3", "old_price": null, "price": "\n                           20,173 \u20ac ", "consumption": "used 2006 bmw m3 smg convertible 79,000 miles in black for sale | carsite", "date": " 03/07/2020", "fuel_type": "Gasoline", "mileage": "127,138 Km", "year": "2006", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Aston martin", "model": "Rapide", "engine_size": "V12 5.9", "model_type": "V12 5.9", "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 2017 aston martin rapide v12 touchtronic iii auto s hatchback 15,000 miles in silver ", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2017", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "Sl 500", "model_type": "Sl 500", "old_price": null, "price": "\n                           15,460 \u20ac ", "consumption": "used 1996 mercedes-benz 500 sl500 convertible 144,900 miles in red for sale | carsite", "date": " 08/07/2020", "fuel_type": "Gasoline", "mileage": "233,194 Km", "year": "1996", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Renault", "model": "Scenic", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           3,559 \u20ac ", "consumption": "used 2010 renault scenic dynamique vvt 5-door not specified 72,000 miles in red for sale |", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "2010", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class coupe", "engine_size": "E 220", "model_type": "E 220", "old_price": null, "price": "\n                           8,319 \u20ac ", "consumption": "used 1995 mercedes-benz e class e220 coupe 130,000 miles in green for sale | carsite", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "209,215 Km", "year": "1995", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Polo", "engine_size": "1.0", "model_type": "1.0", "old_price": null, "price": "\n                           16,603 \u20ac ", "consumption": "used 2019 volkswagen polo evo 80ps start-stop se hatchback 5,200 miles in grey for sale | ", "date": " 09/07/2020", "fuel_type": "Gasoline", "mileage": "8,369 Km", "year": "2019", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Vauxhall", "model": "Grandland x", "engine_size": "1.5", "model_type": "1.5", "old_price": null, "price": "\n                           19,578 \u20ac ", "consumption": "used 2018 vauxhall grandland x 1.5 130 turbo d blueinjection start-stop sport nav hatchbac", "date": " 09/07/2020", "fuel_type": "Diesel", "mileage": "9,495 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Golf", "engine_size": "Gti", "model_type": "Gti", "old_price": null, "price": "\n                           30,647 \u20ac ", "consumption": "volkswagen golf 2.0 tsi gti dsg (s/s) 5dr", "date": " 29/09/2020", "fuel_type": "Gasoline", "mileage": "24,140 Km", "year": "2018", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Tipo", "engine_size": "1.4", "model_type": "1.4", "old_price": null, "price": "\n                           11,842 \u20ac ", "consumption": "used 2017 fiat tipo lounge hatchback 4,800 miles in grey for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "7,725 Km", "year": "2017", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Sl-class", "engine_size": "CLASSIC", "model_type": "CLASSIC", "old_price": null, "price": "\n                           95,153 \u20ac ", "consumption": "used 1962 mercedes-benz sl class 230 not specified in silver for sale | carsite", "date": " 22/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1962", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alvis", "model": "Td 21", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           89,202 \u20ac ", "consumption": "used 1960 alvis 12/70 td21 convertible in blue for sale | carsite", "date": " 23/10/2020", "fuel_type": "Gasoline", "mileage": "-", "year": "1960", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Fiat", "model": "Ducato", "engine_size": "2.3", "model_type": "2.3", "old_price": null, "price": "\n                           33,319 \u20ac ", "consumption": "luton low loader maxi euro 6", "date": " 10/11/2020", "fuel_type": "Diesel", "mileage": "16 Km", "year": "2021", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "E-class", "engine_size": "E 350", "model_type": "E 350", "old_price": null, "price": "\n                           42,786 \u20ac ", "consumption": "used 2019 mercedes-benz e class e 350 amg line coupe 9,000 miles in grey for sale | carsit", "date": " 24/11/2020", "fuel_type": "Gasoline", "mileage": "14,484 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Toyota", "model": "Aygo", "engine_size": "X PLAY", "model_type": "X PLAY", "old_price": null, "price": "\n                           8,211 \u20ac ", "consumption": "toyota aygo 1.0 vvt-i x-play 5dr", "date": " 09/02/2021", "fuel_type": "Gasoline", "mileage": "70,930 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mercedes", "model": "Cla-class", "engine_size": "Cla 250", "model_type": "Cla 250", "old_price": null, "price": "\n                           41,596 \u20ac ", "consumption": "used 2020 mercedes-benz cla class cla 250 e amg line premium coupe 1,651 miles in silver f", "date": " 27/02/2021", "fuel_type": "Gasoline", "mileage": "2,657 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Lexus", "model": null, "engine_size": "Ux 250h", "model_type": "Ux 250h", "old_price": null, "price": "\n                           30,528 \u20ac ", "consumption": "used 2019 lexus ux premium hatchback 1,400 miles in grey for sale | carsite", "date": " 02/03/2021", "fuel_type": "Gasoline", "mileage": "2,253 Km", "year": "2019", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": "1.3", "model_type": "1.3", "old_price": null, "price": "\n                           9,515 \u20ac ", "consumption": "2018 alfa romeo mito 1.3jtdm-2", "date": " 10/03/2021", "fuel_type": "Diesel", "mileage": "70,811 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Bmw", "model": "I3", "engine_size": "M SPORT", "model_type": "M SPORT", "old_price": null, "price": "\n                           33,146 \u20ac ", "consumption": "used 2020 bmw i3 i3s hatchback 5,900 miles in black for sale | carsite", "date": " 13/04/2021", "fuel_type": "Electric", "mileage": "9,495 Km", "year": "2020", "transmission_type": "Automatic", "add_number": "SG8"}
{"manufacturer": "Volkswagen", "model": "Beetle", "engine_size": "1.2", "model_type": "1.2", "old_price": null, "price": "\n                           14,282 \u20ac ", "consumption": "volkswagen beetle 3dr 1.2", "date": " 19/04/2021", "fuel_type": "Gasoline", "mileage": "115,873 Km", "year": "1982", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Kia", "model": "Soul", "engine_size": "1.6", "model_type": "1.6", "old_price": null, "price": "\n                           2,975 \u20ac ", "consumption": "kia soul 1.6 echo 5dr", "date": " 27/04/2021", "fuel_type": "Gasoline", "mileage": "180,247 Km", "year": "2011", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Alfa romeo", "model": "Mito", "engine_size": null, "model_type": null, "old_price": null, "price": "\n                           9,520 \u20ac ", "consumption": "alfa romeo mito jtdm-2 1.3 3dr", "date": " 06/05/2021", "fuel_type": "Diesel", "mileage": "71,069 Km", "year": "2018", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Ford", "model": "Fiesta", "engine_size": "1.25", "model_type": "1.25", "old_price": null, "price": "\n                           3,565 \u20ac ", "consumption": "2009 ford fiesta 1.25 style (82ps) 5d", "date": " 19/05/2021", "fuel_type": "Gasoline", "mileage": "160,452 Km", "year": "2009", "transmission_type": "Manual", "add_number": "SG8"}
{"manufacturer": "Mini", "model": "Countryman", "engine_size": "Cooper", "model_type": "Cooper", "old_price": null, "price": "\n                           30,690 \u20ac ", "consumption": "129g co2/km (komb.),5.6l/100km (komb.)", "date": " 06/11/2020", "fuel_type": "Gasoline", "mileage": "10 Km", "year": "2022", "transmission_type": "Manual", "add_number": "47533"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mini", "model": "Countryman"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Fiat", "model": "Doblo"}
{"manufacturer": "Bmw", "model": "3 series convertible"}
{"manufacturer": "Aston martin", "model": "Rapide"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Renault", "model": "Scenic"}
{"manufacturer": "Mercedes", "model": "E-class coupe"}
{"manufacturer": "Volkswagen", "model": "Polo"}
{"manufacturer": "Vauxhall", "model": "Grandland x"}
{"manufacturer": "Volkswagen", "model": "Golf"}
{"manufacturer": "Fiat", "model": "Tipo"}
{"manufacturer": "Mercedes", "model": "Sl-class"}
{"manufacturer": "Alvis", "model": "Td 21"}
{"manufacturer": "Fiat", "model": "Ducato"}
{"manufacturer": "Mercedes", "model": "E-class"}
{"manufacturer": "Toyota", "model": "Aygo"}
{"manufacturer": "Mercedes", "model": "Cla-class"}
{"manufacturer": "Lexus", "model": "Ux 250h"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Bmw", "model": "I3"}
{"manufacturer": "Volkswagen", "model": "Beetle"}
{"manufacturer": "Kia", "model": "Soul"}
{"manufacturer": "Alfa romeo", "model": "Mito"}
{"manufacturer": "Ford", "model": "Fiesta"}
{"manufacturer": "Mini", "model": "Countryman"}
