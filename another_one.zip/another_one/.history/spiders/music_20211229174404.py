import scrapy
from scrapy_splash import SplashRequest
from scrapy import Field
from itemloaders.processors import TakeFirst
from scrapy.loader import ItemLoader
from scrapy.crawler import CrawlerProcess

class MusicItem(scrapy.Item):
    tracks  = Field(output_processor = TakeFirst())
    artists  = Field(output_processor = TakeFirst())
    stuff  = Field(output_processor = TakeFirst())

class MusicSpider(scrapy.Spider):
    name = 'trax'
    start_urls = ["https://www.traxsource.com/genre/13/deep-house/all?cn=tracks&ipp=50&period=today&gf=13"]

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                callback = self.parse
            )
    def parse(self, response):
        tracklist = response.xpath("(//div[@id='trackListPage'])")
        for tracks in tracklist:
            loaders = ItemLoader(MusicItem(), selector = tracks)
            loaders.add_xpath('tracks', './/div[@class="trk-cell artists"]/a//@href')
            loaders.add_xpath('artists', './/div//div[@class="trk-cell title"]/a//@href')
            yield loaders.load_item()

process = CrawlerProcess(
    settings = {
        'FEED_URI':'music.jl',
        "FEED_FORMAT":'jsonlines'
    }
)

process.crawl(MusicSpider)
process.start()