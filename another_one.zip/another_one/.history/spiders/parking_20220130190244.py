from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_playwright.page import PageCoroutine
import pandas as pd
from scrapy_splash import SplashRequest



class parkingSpider(scrapy.Spider):
https://www.theparking.eu/used-cars/.html