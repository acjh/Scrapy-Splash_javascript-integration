from dataclasses import Field
from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_playwright.page import PageCoroutine
import pandas as pd
from scrapy_splash import SplashRequest
from scrapy.loader import ItemLoader
from scrapy.item import Field
from itemloaders.processors import TakeFirst


script = """function main(splash)
                local url = splash.args.url
                assert(splash:go(url))
                assert(splash:wait(1))
                assert(splash:runjs('document.getElementsByClassName("btn-next")[0].children[0].click()'))
                assert(splash:wait(1.5))     -- to this
                return {html = splash:html()}                
                end"""
class parkingItem(scrapy.Item):
    manufacturer = Field(output_processor = TakeFirst())
    model = Field(output_processor = TakeFirst())
    engine_size = Field(output_processor = TakeFirst())
    model_type = Field(output_processor = TakeFirst())
    old_price = Field(output_processor = TakeFirst())
    price = Field(output_processor = TakeFirst())
    consumption = Field(output_processor = TakeFirst())
    date = Field(output_processor = TakeFirst())
    fuel_type = Field(output_processor = TakeFirst())
    mileage = Field(output_processor = TakeFirst())
    year = Field(output_processor = TakeFirst())
    transmission_type = Field(output_processor = TakeFirst())
    add_number = Field(output_processor = TakeFirst())

class parkingSpider(scrapy.Spider):
    name = 'parking'
    start_urls= ['https://www.theparking.eu/used-cars/.html']

    def parse(self, response):
        section = response.css('li.li-result')
        for item in section:
            loader = ItemLoader(parkingSpider(), selector = item)
            loader.add_xpath('manufacturer', './/a//span[@class="title-block brand"]//text()')
            loader.add_xpath('model', '.(//a//span[@class="sub-title title-block"])[position() mod 2 =1]//text()')
            yield loader.load_item()
        next_page = response.css('li.btn-next').extract_first() #pagination    
        if next_page:
            #print(response)
            yield(SplashRequest(response.urljoin(next_page), self.parse,
                endpoint='execute',
                cache_args=['lua_source'],
                args={'lua_source': script},  

            ))

process = CrawlerProcess(
    settings = {
        'FEED_URI':'parking.jl',
        'FEED_FORMAT':'jsonlines'
    }
)
process.crawl(parkingSpider)
process.start()