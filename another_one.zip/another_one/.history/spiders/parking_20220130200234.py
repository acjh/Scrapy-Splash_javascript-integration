from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_playwright.page import PageCoroutine
import pandas as pd
from scrapy_splash import SplashRequest
from scrapy.loader import ItemLoader


script = """function main(splash)
                local url = splash.args.url
                assert(splash:go(url))
                assert(splash:wait(1))
                -- assert(splash:runjs('document.getElementsByClassName("btn-next")[0].click()'))          -- Change this
                assert(splash:runjs('document.getElementsByClassName("btn-next")[0].children[0].click()')) -- to this
                -- assert(splash:wait(0.75)) -- Change this
                assert(splash:wait(1.5))     -- to this
                -- return result as a JSON object
                return {html = splash:html()}                
                end"""

class parkingSpider(scrapy.Spider):
    name = 'parking'
    start_urls= ['https://www.theparking.eu/used-cars/.html']

    

    def parse(self, response):
        section = response.css('li.li-result')
        for item in section:
            yield{
                'manufacturer' :  item.css('span.brand::text').extract_first(),
                'model' : item.css('span.sub-title::text').extract_first(),
                'engine_size' :  item.css('span.nowrap::text').extract_first(),
                'model_type' : item.css('span span.nowrap::text').extract_first(),
                'old_price' : item.css('li.li-result p.old-prix span::text').extract_first(),    
                'price' : item.css('li.li-result p.prix::text').extract_first(),
                'consumption' : item.css('li.li-result div.desc::text').extract_first(),
                'date' : item.css('p.btn-publication::text').extract_first(),
                'fuel_type' : item.css('div.bc-info div.upper::text').extract_first(),
                'mileage' : item.css('li.li-result div.bc-info ul div::text')[1].extract(),
                'year' : item.css('li.li-result div.bc-info ul div::text')[2].extract(),
                'transmission_type' : item.css('li.li-result div.bc-info ul div::text')[3].extract(),
                'add_number' : item.css('li.li-result div.bc-info ul div::text')[4].extract(),

            }

        next_page = response.css('li.btn-next').extract_first() #pagination    
        if next_page != 0:
            print(response)
            yield(SplashRequest(response.urljoin(next_page), self.parse,
                endpoint='execute',
                cache_args=['lua_source'],
                args={'lua_source': script},  

            ))

process = CrawlerProcess(
    settings = {
        'FEED_URI':'parking.jl',
        'FEED_FORMAT':'jsonlines'
    }
)
process.crawl(parkingSpider)
process.start()