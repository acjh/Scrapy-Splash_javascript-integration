import scrapy
from scrapy_selenium import SeleniumRequest

class CatpchaSpider(scrapy.Spider):
    name = 'captcha'
    start_urls = ['https://uk.indeed.com/jobs?q=degree%20mathematics&l=london&limit=100&filter=0&start=1200&vjk=a282cf072b5174d8']

    def start_requests(self):
        for url in self.start_urls:
            yield SeleniumRequest(
                url, 
                callback = self.parse,
                wait_time = 10
            )
    def parse(self, response):
        