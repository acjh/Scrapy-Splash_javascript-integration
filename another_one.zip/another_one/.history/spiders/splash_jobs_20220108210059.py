from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_playwright.page import PageCoroutine
import pandas as pd
from scrapy_splash import SplashRequest

class JobSpider(scrapy.Spider):
    name = 'job_play'

    start_urls = pd.read_csv("/Users/emiljanmrizaj/Downloads/links.csv")
    
    #html = f'https://www.jobsite.co.uk/jobs/{}' We implement this if it works

    custom_settings = {
        'USER_AGENT':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Safari/605.1.15',
    }



    def start_requests(self):

        script = """function main(splash, args)
        assert(splash:go(args.url))
        assert(splash:wait(0.5))
        return {
         html = splash:html(),
            }
        end"""


        for urls in self.start_urls.urls:
            yield SplashRequest(
                    url = urls,
                    callback = self.parse,
                    endpoint='execute',
                    args={'lua_source':script,'timeout':3600})
                    
    def parse(self, response):
        for jobs in response.xpath("//a[contains(@class, 'sc-fzqBkg')][last()]"):
            yield response.follow(
                jobs,
                callback=self.parse_jobs,
                
            )

    async def parse_jobs(self, response):
        yield {
            "url": response.url,
            "title": response.xpath("//h1[@class='brand-font']//text()").get(),
            "price": response.xpath("//li[@class='salary icon']//div//text()").get(),
            "organisation": response.xpath("//a[@id='companyJobsLink']//text()").get()
        }
process = CrawlerProcess(
        settings={          
            "FEED_URI":'jobs_test3.jl',
            "FEED_FORMAT":'jsonlines',
        }
    )
process.crawl(JobSpider)
process.start()