import scrapy
from scrapy_splash import SplashRequest

class TeslaSpider(scrapy.Spider):
    name = 'tesla'
    allowed_domains = ['tesla.com']
    start_urls = ['https://www.tesla.com/en_ca/models/design#overview']

    def start_requests(self):
        for url in self.start_urls:
            yield SplashRequest(
                url,
                callback = self.parse, 
                endpoints = 'render.html',
                args = {
                    'wait':2,
                    'html':1,
                    'timeout':10   
                     }
            )


    def parse(self, response):
        test = response.xpath("//title/text()")
        yield test