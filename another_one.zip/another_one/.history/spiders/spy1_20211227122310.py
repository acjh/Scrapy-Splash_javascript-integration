import scrapy
from scrapy_splash import SplashRequest

class TeslaSpider(scrapy.Spider):
    name = 'tesla'
    allowed_domains = ['tesla.com']
    start_urls = ['https://www.tesla.com/en_ca/models/design#overview',]


    def parse(self, response):
        yield SplashRequest(
            self.start_urls[0],
            endpoint='render.html',
            args={
                    'wait': 2,
                    'html': 1,
                    'timeout': 10,
                })
        link = response.xpath("//title/text()")
        yield link