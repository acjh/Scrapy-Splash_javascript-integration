import scrapy
from scrapy.loader import ItemLoader
from itemloaders.processors import TakeFirst
from scrapy.item import Field
from scrapy.crawler import CrawlerProcess
from scrapy.http.request.form import FormRequest
from scrapy_splash import SplashRequest
from scrapy_splash.request import SplashFormRequest
class MalItem(scrapy.Item):
    listings = Field(output_processor = TakeFirst())


class MalSpider(scrapy.Spider):
    name = 'Mal'
    
    #start_urls = []
    start_urls = 'https://www.edgeprop.my/jwdsonic/api/v1/property/search?&listing_type=sale&state=Malaysia&property_type=rl&start=0&size=20'
    #for i in range(0, 5):
    #    start_urls.append(f'https://www.edgeprop.my/jwdsonic/api/v1/property/search?&listing_type=sale&state=Malaysia&property_type=rl&start={i}&size=20')

    custom_settings = {
        #'LOG_LEVEL': 'CRITICAL',
        'ROBOTSTXT_OBEY': False,
        'USER_AGENT': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
        'CONCURRENT_REQUESTS': 100,
        'CONCURRENT_REQUESTS_PER_IP': 100
    }
    def start_requests(self):
        for url in self.start_urls:
            for i in range(0, 7709):
                yield SplashFormRequest(
                url, 
                method='GET',
                formdata = {
                    'listing_type': 'sale',
                    'state': 'Malaysia',
                    'property_type': 'rl',
                    'start': str(i),
                    'size': '20'
                },
                callback = self.parse
            )
    
    def parse(self, response):
        links = response.json().get('property')
        for stuff in links:
            loader = ItemLoader(MalItem())
            loader.add_value('listings', stuff)
            yield loader.load_item()

process = CrawlerProcess(

    settings = {
        "FEED_URI":'stuff.jl',
        "FEED_FORMAT":'jsonlines'
    }
)