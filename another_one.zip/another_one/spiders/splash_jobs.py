from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_playwright.page import PageCoroutine
import pandas as pd
from scrapy_splash import SplashRequest

class JobSpider(scrapy.Spider):
    name = 'job_play'

    start_urls = pd.read_csv("/Users/emiljanmrizaj/Downloads/links.csv")
    
    #html = f'https://www.jobsite.co.uk/jobs/{}' We implement this if it works

    custom_settings = {
        'USER_AGENT':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36',
    }

    script3 = """
        function main(splash, args)
            local ok, result = splash:with_timeout(function()
            --enabling the return of splash response
            splash.request_body_enabled = true
            --set your user agent
            splash:set_user_agent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36')
            splash.private_mode_enabled = false
            
            --visit the given url
            local url = args.url
            local ok, reason = splash:go(url)
            if ok then
                --if no error found, wait for 1 second for the page to render
                splash:wait(1)
                --store the html content in a variable
                local content = assert(splash:html())
                --return the content
                return content
            end
        end,3600)
        
        return result
        
        end"""


    def start_requests(self):

        for urls in self.start_urls.urls:
            yield SplashRequest(
                    url = urls,
                    callback = self.parse,
                    endpoint='execute',
                    args={'lua_source':self.script3,'timeout':3600})
                    
    def parse(self, response):
        for jobs in response.xpath("//a[contains(@class, 'sc-fzqBkg')][last()]"):
            yield response.follow(
                jobs,
                callback=self.parse_jobs,
                
            )

    async def parse_jobs(self, response):
        yield {
            "url": response.url,
            "title": response.xpath("//h1[@class='brand-font']//text()").get(),
            "price": response.xpath("//li[@class='salary icon']//div//text()").get(),
            "organisation": response.xpath("//a[@id='companyJobsLink']//text()").get()
        }
process = CrawlerProcess(
        settings={          
            "FEED_URI":'jobs_test3.jl',
            "FEED_FORMAT":'jsonlines',
        }
    )
process.crawl(JobSpider)
process.start()